def skill():
    return ["olives", "onion", "tuna"]
