poetry run python hackathon_template/main.py
